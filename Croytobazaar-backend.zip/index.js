import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// ✅ Market API
app.get("/api/market", async (req, res) => {
  try {
    const url =
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,solana,ripple,cardano,dogecoin,polkadot,avalanche,tron,polygon,litecoin,chainlink,stellar,shiba-inu";
    const data = await fetch(url).then((r) => r.json());
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ✅ AI Signal (Demo Logic)
app.post("/api/signal", async (req, res) => {
  const { coin, price } = req.body;
  let signal = "HOLD";
  if (price < 100) signal = "BUY";
  if (price > 50000) signal = "SELL";
  res.json({ coin, price, signal });
});

// ✅ Backtesting
app.post("/api/backtest", async (req, res) => {
  try {
    const { coin, start, end } = req.body;
    const url = `https://api.coingecko.com/api/v3/coins/${coin}/market_chart/range?vs_currency=usd&from=${new Date(
      start
    ).getTime() / 1000}&to=${new Date(end).getTime() / 1000}`;
    const data = await fetch(url).then((r) => r.json());
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("✅ Backend running on port " + PORT));